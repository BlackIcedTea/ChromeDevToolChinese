// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// This is to work-around an issue where this extension is not granted
// permission to access chrome://resources when iframed for print preview.
// See https://crbug.com/444752.
