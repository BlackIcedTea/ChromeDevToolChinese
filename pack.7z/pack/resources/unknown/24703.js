// Copyright 2014 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.


'use strict';

(function() {
  var mojomId = 'headless/lib/tab_socket.mojom';
  if (mojo.internal.isMojomLoaded(mojomId)) {
    console.warn('The following mojom is loaded multiple times: ' + mojomId);
    return;
  }
  mojo.internal.markMojomLoaded(mojomId);

  // TODO(yzshen): Define these aliases to minimize the differences between the
  // old/new modes. Remove them when the old mode goes away.
  var bindings = mojo;
  var associatedBindings = mojo;
  var codec = mojo.internal;
  var validator = mojo.internal;

  var exports = mojo.internal.exposeNamespace('headless');



  function TabSocket_SendMessageToEmbedder_Params(values) {
    this.initDefaults_();
    this.initFields_(values);
  }


  TabSocket_SendMessageToEmbedder_Params.prototype.initDefaults_ = function() {
    this.message = null;
    this.v8ExecutionContextId = 0;
  };
  TabSocket_SendMessageToEmbedder_Params.prototype.initFields_ = function(fields) {
    for(var field in fields) {
        if (this.hasOwnProperty(field))
          this[field] = fields[field];
    }
  };

  TabSocket_SendMessageToEmbedder_Params.validate = function(messageValidator, offset) {
    var err;
    err = messageValidator.validateStructHeader(offset, codec.kStructHeaderSize);
    if (err !== validator.validationError.NONE)
        return err;

    var kVersionSizes = [
      {version: 0, numBytes: 24}
    ];
    err = messageValidator.validateStructVersion(offset, kVersionSizes);
    if (err !== validator.validationError.NONE)
        return err;


    
    // validate TabSocket_SendMessageToEmbedder_Params.message
    err = messageValidator.validateStringPointer(offset + codec.kStructHeaderSize + 0, false)
    if (err !== validator.validationError.NONE)
        return err;


    return validator.validationError.NONE;
  };

  TabSocket_SendMessageToEmbedder_Params.encodedSize = codec.kStructHeaderSize + 16;

  TabSocket_SendMessageToEmbedder_Params.decode = function(decoder) {
    var packed;
    var val = new TabSocket_SendMessageToEmbedder_Params();
    var numberOfBytes = decoder.readUint32();
    var version = decoder.readUint32();
    val.message = decoder.decodeStruct(codec.String);
    val.v8ExecutionContextId = decoder.decodeStruct(codec.Int32);
    decoder.skip(1);
    decoder.skip(1);
    decoder.skip(1);
    decoder.skip(1);
    return val;
  };

  TabSocket_SendMessageToEmbedder_Params.encode = function(encoder, val) {
    var packed;
    encoder.writeUint32(TabSocket_SendMessageToEmbedder_Params.encodedSize);
    encoder.writeUint32(0);
    encoder.encodeStruct(codec.String, val.message);
    encoder.encodeStruct(codec.Int32, val.v8ExecutionContextId);
    encoder.skip(1);
    encoder.skip(1);
    encoder.skip(1);
    encoder.skip(1);
  };
  var kTabSocket_SendMessageToEmbedder_Name = 0;

  function TabSocketPtr(handleOrPtrInfo) {
    this.ptr = new bindings.InterfacePtrController(TabSocket,
                                                   handleOrPtrInfo);
  }

  function TabSocketAssociatedPtr(associatedInterfacePtrInfo) {
    this.ptr = new associatedBindings.AssociatedInterfacePtrController(
        TabSocket, associatedInterfacePtrInfo);
  }

  TabSocketAssociatedPtr.prototype =
      Object.create(TabSocketPtr.prototype);
  TabSocketAssociatedPtr.prototype.constructor =
      TabSocketAssociatedPtr;

  function TabSocketProxy(receiver) {
    this.receiver_ = receiver;
  }
  TabSocketPtr.prototype.sendMessageToEmbedder = function() {
    return TabSocketProxy.prototype.sendMessageToEmbedder
        .apply(this.ptr.getProxy(), arguments);
  };

  TabSocketProxy.prototype.sendMessageToEmbedder = function(message, v8ExecutionContextId) {
    var params = new TabSocket_SendMessageToEmbedder_Params();
    params.message = message;
    params.v8ExecutionContextId = v8ExecutionContextId;
    var builder = new codec.MessageV0Builder(
        kTabSocket_SendMessageToEmbedder_Name,
        codec.align(TabSocket_SendMessageToEmbedder_Params.encodedSize));
    builder.encodeStruct(TabSocket_SendMessageToEmbedder_Params, params);
    var message = builder.finish();
    this.receiver_.accept(message);
  };

  function TabSocketStub(delegate) {
    this.delegate_ = delegate;
  }
  TabSocketStub.prototype.sendMessageToEmbedder = function(message, v8ExecutionContextId) {
    return this.delegate_ && this.delegate_.sendMessageToEmbedder && this.delegate_.sendMessageToEmbedder(message, v8ExecutionContextId);
  }

  TabSocketStub.prototype.accept = function(message) {
    var reader = new codec.MessageReader(message);
    switch (reader.messageName) {
    case kTabSocket_SendMessageToEmbedder_Name:
      var params = reader.decodeStruct(TabSocket_SendMessageToEmbedder_Params);
      this.sendMessageToEmbedder(params.message, params.v8ExecutionContextId);
      return true;
    default:
      return false;
    }
  };

  TabSocketStub.prototype.acceptWithResponder =
      function(message, responder) {
    var reader = new codec.MessageReader(message);
    switch (reader.messageName) {
    default:
      return false;
    }
  };

  function validateTabSocketRequest(messageValidator) {
    var message = messageValidator.message;
    var paramsClass = null;
    switch (message.getName()) {
      case kTabSocket_SendMessageToEmbedder_Name:
        if (!message.expectsResponse() && !message.isResponse())
          paramsClass = TabSocket_SendMessageToEmbedder_Params;
      break;
    }
    if (paramsClass === null)
      return validator.validationError.NONE;
    return paramsClass.validate(messageValidator, messageValidator.message.getHeaderNumBytes());
  }

  function validateTabSocketResponse(messageValidator) {
    return validator.validationError.NONE;
  }

  var TabSocket = {
    name: 'headless::TabSocket',
    kVersion: 0,
    ptrClass: TabSocketPtr,
    proxyClass: TabSocketProxy,
    stubClass: TabSocketStub,
    validateRequest: validateTabSocketRequest,
    validateResponse: null,
  };
  TabSocketStub.prototype.validator = validateTabSocketRequest;
  TabSocketProxy.prototype.validator = null;
  exports.TabSocket = TabSocket;
  exports.TabSocketPtr = TabSocketPtr;
  exports.TabSocketAssociatedPtr = TabSocketAssociatedPtr;
})();