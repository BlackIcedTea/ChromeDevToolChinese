// Copyright 2014 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.


define("extensions/common/mojo/keep_alive.mojom", [
    "mojo/public/js/associated_bindings",
    "mojo/public/js/bindings",
    "mojo/public/js/codec",
    "mojo/public/js/core",
    "mojo/public/js/validator",
], function(associatedBindings, bindings, codec, core, validator) {
  var exports = {};


  function KeepAlivePtr(handleOrPtrInfo) {
    this.ptr = new bindings.InterfacePtrController(KeepAlive,
                                                   handleOrPtrInfo);
  }

  function KeepAliveAssociatedPtr(associatedInterfacePtrInfo) {
    this.ptr = new associatedBindings.AssociatedInterfacePtrController(
        KeepAlive, associatedInterfacePtrInfo);
  }

  KeepAliveAssociatedPtr.prototype =
      Object.create(KeepAlivePtr.prototype);
  KeepAliveAssociatedPtr.prototype.constructor =
      KeepAliveAssociatedPtr;

  function KeepAliveProxy(receiver) {
    this.receiver_ = receiver;
  }

  function KeepAliveStub(delegate) {
    this.delegate_ = delegate;
  }

  KeepAliveStub.prototype.accept = function(message) {
    var reader = new codec.MessageReader(message);
    switch (reader.messageName) {
    default:
      return false;
    }
  };

  KeepAliveStub.prototype.acceptWithResponder =
      function(message, responder) {
    var reader = new codec.MessageReader(message);
    switch (reader.messageName) {
    default:
      return false;
    }
  };

  function validateKeepAliveRequest(messageValidator) {
    return validator.validationError.NONE;
  }

  function validateKeepAliveResponse(messageValidator) {
    return validator.validationError.NONE;
  }

  var KeepAlive = {
    name: 'extensions::KeepAlive',
    kVersion: 0,
    ptrClass: KeepAlivePtr,
    proxyClass: KeepAliveProxy,
    stubClass: KeepAliveStub,
    validateRequest: validateKeepAliveRequest,
    validateResponse: null,
  };
  KeepAliveStub.prototype.validator = validateKeepAliveRequest;
  KeepAliveProxy.prototype.validator = null;
  exports.KeepAlive = KeepAlive;
  exports.KeepAlivePtr = KeepAlivePtr;
  exports.KeepAliveAssociatedPtr = KeepAliveAssociatedPtr;

  return exports;
});